USE machin_box;
CREATE TABLE Box (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Model NVARCHAR(50) NOT NULL,
    CarBrand NVARCHAR(50) NOT NULL,
    Year INT NULL,
    IsAutomatic BIT DEFAULT 1
);
GO


CREATE TABLE Client (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    PhoneNumber NVARCHAR(20) NOT NULL,
    Email NVARCHAR(100) NULL
);
GO


CREATE TABLE Spare_parts (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    PartNumber NVARCHAR(50) NOT NULL UNIQUE,
    Quantity INT NOT NULL DEFAULT 0 CHECK (Quantity >= 0),
    Price DECIMAL(10,2) NOT NULL CHECK (Price >= 0),
    Id_Box INT NOT NULL,
    FOREIGN KEY (Id_Box) REFERENCES Box(Id)
);
GO


CREATE TABLE Orders (
    Id INT PRIMARY KEY IDENTITY(1,1),
    OrderDate DATETIME NOT NULL DEFAULT GETDATE(),
    ClientId INT NOT NULL,
    TotalAmount DECIMAL(10,2) NOT NULL,
    Status NVARCHAR(20) NOT NULL DEFAULT 'Processing',
    FOREIGN KEY (ClientId) REFERENCES Client(Id)
);
GO



