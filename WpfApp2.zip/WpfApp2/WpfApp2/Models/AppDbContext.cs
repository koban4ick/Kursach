﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace WpfApp2.Models
{
    public class AppDbContext : DbContext
    {
        public DbSet<Box> Box { get; set; }
        public DbSet<Client> Client { get; set; }
        public DbSet<Spare_parts> Spare_parts { get; set; }
        public DbSet<Orders> Orders { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
                @"Server=(localdb)\mssqllocaldb;Database=machin_box;Trusted_Connection=True;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Конфигурация для Box
            modelBuilder.Entity<Box>(entity =>
            {
                entity.ToTable("Box");
                entity.HasKey(b => b.Id);

                // Настройка связи один-ко-многим
                entity.HasMany(b => b.SpareParts)
                    .WithOne(sp => sp.Box)
                    .HasForeignKey(sp => sp.BoxId)  // Или Id_Box, если используете это имя
                    .OnDelete(DeleteBehavior.Cascade); // Добавьте поведение при удалении

                // Дополнительные настройки для Box
                entity.Property(b => b.Model).HasMaxLength(100);
                entity.Property(b => b.CarBrand).HasMaxLength(50);
            });

            // Конфигурация для Spare_parts
            modelBuilder.Entity<Spare_parts>(entity =>
            {
                entity.ToTable("Spare_parts");
                entity.HasKey(sp => sp.Id);

                entity.Property(sp => sp.Name).HasMaxLength(200);
                entity.Property(sp => sp.PartNumber).HasMaxLength(50);
            });

            // Конфигурация для других таблиц
            modelBuilder.Entity<Client>().ToTable("Client");
            modelBuilder.Entity<Orders>().ToTable("Order");
        }
    }
}