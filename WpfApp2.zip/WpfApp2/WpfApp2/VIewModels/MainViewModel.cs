﻿using Microsoft.EntityFrameworkCore;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using WpfApp2.Models;

namespace WpfApp2.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private ObservableCollection<Box> _box;
        private ObservableCollection<Client> _client;
        private ObservableCollection<Spare_parts> _sparePart;
        private ObservableCollection<Orders> _order;

        // Изменено на public
        public ObservableCollection<Box> Boxes
        {
            get => _box;
            set { _box = value; OnPropertyChanged(nameof(Boxes)); }
        }

        // Изменено на public
        public ObservableCollection<Client> Clients
        {
            get => _client;
            set { _client = value; OnPropertyChanged(nameof(Clients)); }
        }

        // Изменено на public (обратите внимание на правильное написание SpareParts)
        public ObservableCollection<Spare_parts> SpareParts
        {
            get => _sparePart;
            set { _sparePart = value; OnPropertyChanged(nameof(Spare_parts)); }
        }

        // Изменено на public
        public ObservableCollection<Orders> Orders
        {
            get => _order;
            set { _order = value; OnPropertyChanged(nameof(Orders)); }
        }

        public MainViewModel()
        {
            LoadData();
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


        private void LoadData()
        {
            try
            {
                using (var context = new AppDbContext())
                {
                    Boxes = new ObservableCollection<Box>(context.Box.ToList());
                    Clients = new ObservableCollection<Client>(context.Client.ToList());
                    SpareParts = new ObservableCollection<Spare_parts>(
    context.Spare_parts.Include(sp => sp.Box).ToList());
                    Orders = new ObservableCollection<Orders>(context.Orders.Include(o => o.Client).ToList());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}\n{ex.InnerException?.Message}",
                              "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
    }
