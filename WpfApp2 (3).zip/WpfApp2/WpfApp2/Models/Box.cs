﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp2.Models
{
    public class Box
    {
        public int Id { get; set; }
        public string Model { get; set; }
        public string CarBrand { get; set; }
        public int? Year { get; set; }
        public bool IsAutomatic { get; set; } = true;

        public List<Spare_parts> SpareParts { get; set; } = new List<Spare_parts>(); // ✅ Верно
    }
}
