﻿using System.Windows;
using WpfApp2.ViewModels;

namespace WpfApp2
{
    public partial class BaseData : Window
    {
        public BaseData()
        {
            InitializeComponent();
            DataContext = new MainViewModel(); // Установка ViewModel
        }
    }
}