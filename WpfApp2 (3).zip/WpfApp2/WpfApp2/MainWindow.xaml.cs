﻿using System.Windows;

namespace WpfApp2
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new ViewModels.MainViewModel(); 
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var baseDataWindow = new BaseData();
            baseDataWindow.Show();
            Close();
        }
    }
}