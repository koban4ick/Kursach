﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using WpfApp2.Models;

namespace WpfApp2.ViewModels
{
    public class SparePartViewModel : INotifyPropertyChanged
    {
        private readonly AppDbContext _context;
        public ObservableCollection<Spare_parts> SpareParts { get; }
        public ObservableCollection<Box> Boxes { get; }
        private Spare_parts _selectedSparePart;

        public Spare_parts SelectedSparePart
        {
            get => _selectedSparePart;
            set
            {
                _selectedSparePart = value;
                OnPropertyChanged();
                CommandManager.InvalidateRequerySuggested();
            }
        }

        public ICommand AddCommand { get; }
        public ICommand DeleteCommand { get; }
        public ICommand SaveCommand { get; }

        public SparePartViewModel(AppDbContext context)
        {
            _context = context;
            SpareParts = new ObservableCollection<Spare_parts>(_context.Spare_parts
                .Include(sp => sp.Box)
                .AsNoTracking()
                .ToList());

            Boxes = new ObservableCollection<Box>(_context.Box.AsNoTracking().ToList());

            AddCommand = new RelayCommand(AddSparePart);
            DeleteCommand = new RelayCommand(DeleteSparePart, CanDeleteSparePart);
            SaveCommand = new RelayCommand(SaveSpareParts);
        }

        private void AddSparePart(object parameter)
        {
            var newPart = new Spare_parts
            {
                Name = "Новая запчасть",
                PartNumber = "Артикул",
                Box = Boxes.FirstOrDefault()
            };
            SpareParts.Add(newPart);
            _context.Spare_parts.Add(newPart);
            SelectedSparePart = newPart;
        }

        private bool CanDeleteSparePart(object parameter) => SelectedSparePart != null;

        private void DeleteSparePart(object parameter)
        {
            if (MessageBox.Show("Удалить запчасть?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                try
                {
                    _context.Spare_parts.Remove(SelectedSparePart);
                    SpareParts.Remove(SelectedSparePart);
                    _context.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка удаления: {ex.Message}");
                }
            }
        }

        private void SaveSpareParts(object parameter)
        {
            try
            {
                _context.SaveChanges();
                MessageBox.Show("Данные запчастей сохранены!");
            }
            catch (DbUpdateException ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.InnerException?.Message}");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}