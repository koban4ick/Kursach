﻿using Microsoft.EntityFrameworkCore;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using WpfApp2.Models;

namespace WpfApp2.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private ObservableCollection<Box> _boxes;
        private ObservableCollection<Client> _client;
        private ObservableCollection<Spare_parts> _sparePart;
        private ObservableCollection<Orders> _order;




        // Изменено на public
        public ObservableCollection<Box> Boxes
        {
            get => _boxes;
            set { _boxes = value; OnPropertyChanged(nameof(Boxes)); }
        }

        // Изменено на public
        public ObservableCollection<Client> Clients
        {
            get => _client;
            set { _client = value; OnPropertyChanged(nameof(Clients)); }
        }

        // Изменено на public (обратите внимание на правильное написание SpareParts)
        public ObservableCollection<Spare_parts> SpareParts
        {
            get => _sparePart;
            set { _sparePart = value; OnPropertyChanged(nameof(SpareParts)); }
        }

        // Изменено на public
        public ObservableCollection<Orders> Orders
        {
            get => _order;
            set { _order = value; OnPropertyChanged(nameof(Orders)); }
        }

        public MainViewModel()
        {
            LoadData();
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


        private void LoadData()
        {
            try
            {
                using (var context = new AppDbContext())
                {
                    // Загрузка данных с включением связанных сущностей
                    var boxes = context.Box.ToList();
                    var clients = context.Client
                        .Include(c => c.Order)  // Жадная загрузка заказов
                        .ToList();

                    var orders = context.Orders
                        .Include(o => o.Client)   // Подгружаем клиента
                        .ToList();

                    var spareParts = context.Spare_parts
    .Include(sp => sp.Box)  // Убедитесь, что связь настроена правильно
    .AsNoTracking()
    .ToList();

                    // Диагностика
                    Debug.WriteLine($"Запчасти: {spareParts.Count} items");
                    if (spareParts.Any())
                    {
                        Debug.WriteLine($"Первая запчасть: {spareParts[0].Name}");
                        Debug.WriteLine($"Привязанная коробка: {spareParts[0].Box?.Model ?? "NULL"}");
                    }

                    SpareParts = new ObservableCollection<Spare_parts>(spareParts);
                    OnPropertyChanged(nameof(SpareParts));

                    // Диагностика
                    Debug.WriteLine($"Загружено:\n" +
                                   $"Коробок: {boxes.Count}\n" +
                                   $"Клиентов: {clients.Count}\n" +
                                   $"Заказов: {orders.Count}\n" +
                                   $"Запчастей: {spareParts.Count}");

                    // Пример проверки первых элементов
                    if (boxes.Any())
                        Debug.WriteLine($"Первая коробка: {boxes[0].Model}");
                    if (clients.Any())
                        Debug.WriteLine($"Первый клиент: {clients[0].Name} (Заказов: {clients[0].Order?.Count})");

                    // Инициализация коллекций
                    Boxes = new ObservableCollection<Box>(boxes);
                    Clients = new ObservableCollection<Client>(clients);
                    Orders = new ObservableCollection<Orders>(orders);
                    SpareParts = new ObservableCollection<Spare_parts>(spareParts);

                    // Уведомление об обновлении всех коллекций
                    OnPropertyChanged(nameof(Boxes));
                    OnPropertyChanged(nameof(Clients));
                    OnPropertyChanged(nameof(Orders));
                    OnPropertyChanged(nameof(SpareParts));
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"ОШИБКА ЗАГРУЗКИ: {ex}");
                MessageBox.Show($"Ошибка загрузки данных:\n{ex.Message}",
                              "Ошибка",
                              MessageBoxButton.OK,
                              MessageBoxImage.Error);
            }
        }
    }

}
