﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input; // Добавлено для ICommand
using Microsoft.EntityFrameworkCore;
using WpfApp2.Models;

namespace WpfApp2.ViewModels
{
    public class ClientViewModel : INotifyPropertyChanged
    {
        private readonly AppDbContext _context;
        public ObservableCollection<Client> Clients { get; }
        private Client _selectedClient;

        public Client SelectedClient
        {
            get => _selectedClient;
            set
            {
                _selectedClient = value;
                OnPropertyChanged();
                // Убрали CommandManager.InvalidateRequerySuggested()
                (DeleteCommand as RelayCommand)?.RaiseCanExecuteChanged();
            }
        }

        public ICommand AddCommand { get; }
        public ICommand DeleteCommand { get; }
        public ICommand SaveCommand { get; }

        public ClientViewModel(AppDbContext context)
        {
            _context = context;
            Clients = new ObservableCollection<Client>(_context.Client
                .Include(c => c.Order)
                .AsNoTracking()
                .ToList());

            AddCommand = new RelayCommand(AddClient);
            DeleteCommand = new RelayCommand(DeleteClient, CanDeleteClient);
            SaveCommand = new RelayCommand(SaveClients);
        }

        private void AddClient(object parameter)
        {
            var newClient = new Client { Name = "Новый клиент", PhoneNumber = "Номер телефона" };
            Clients.Add(newClient);
            _context.Client.Add(newClient);
            SelectedClient = newClient;
        }

        private bool CanDeleteClient(object parameter) => SelectedClient != null;

        private void DeleteClient(object parameter)
        {
            if (MessageBox.Show("Удалить клиента?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                try
                {
                    _context.Client.Remove(SelectedClient);
                    Clients.Remove(SelectedClient);
                    _context.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка удаления: {ex.Message}");
                }
            }
        }

        private void SaveClients(object parameter)
        {
            try
            {
                _context.SaveChanges();
                MessageBox.Show("Данные клиентов сохранены!");
            }
            catch (DbUpdateException ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.InnerException?.Message}");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}