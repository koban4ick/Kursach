﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using WpfApp2.Models;

namespace WpfApp2.ViewModels
{
    public class BoxViewModel : INotifyPropertyChanged
    {
        private readonly AppDbContext _context;
        public ObservableCollection<Box> Boxes { get; }
        private Box _selectedBox;

        public Box SelectedBox
        {
            get => _selectedBox;
            set
            {
                _selectedBox = value;
                OnPropertyChanged();
                CommandManager.InvalidateRequerySuggested(); // Важно для обновления команд
            }
        }

        public ICommand AddCommand { get; }
        public ICommand DeleteCommand { get; }
        public ICommand SaveCommand { get; }

        public BoxViewModel(AppDbContext context)
        {
            _context = context;
            Boxes = new ObservableCollection<Box>(_context.Box.AsNoTracking().ToList());

            AddCommand = new RelayCommand(AddBox);
            DeleteCommand = new RelayCommand(DeleteBox, CanDeleteBox);
            SaveCommand = new RelayCommand(SaveBoxes);
        }

        private void AddBox(object parameter)
        {
            var newBox = new Box { Model = "Новая модель", CarBrand = "Новая марка" };
            Boxes.Add(newBox);
            _context.Box.Add(newBox);
            SelectedBox = newBox;
        }

        private bool CanDeleteBox(object parameter) => SelectedBox != null;

        private void DeleteBox(object parameter)
        {
            if (MessageBox.Show("Удалить коробку?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                try
                {
                    _context.Box.Remove(SelectedBox);
                    Boxes.Remove(SelectedBox);
                    _context.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка удаления: {ex.Message}");
                }
            }
        }

        private void SaveBoxes(object parameter)
        {
            try
            {
                _context.SaveChanges();
                MessageBox.Show("Данные сохранены!");
            }
            catch (DbUpdateException ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.InnerException?.Message}");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}