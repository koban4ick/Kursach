﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using WpfApp2.Models;

namespace WpfApp2.ViewModels
{
    public class OrderViewModel : INotifyPropertyChanged
    {
        private readonly AppDbContext _context;
        public ObservableCollection<Orders> Orders { get; }
        public ObservableCollection<Client> Clients { get; }
        private Orders _selectedOrder;

        public Orders SelectedOrder
        {
            get => _selectedOrder;
            set
            {
                _selectedOrder = value;
                OnPropertyChanged();
                CommandManager.InvalidateRequerySuggested();
            }
        }

        public ICommand AddCommand { get; }
        public ICommand DeleteCommand { get; }
        public ICommand SaveCommand { get; }

        public OrderViewModel(AppDbContext context)
        {
            _context = context;
            Orders = new ObservableCollection<Orders>(_context.Orders
                .Include(o => o.Client)
                .AsNoTracking()
                .ToList());

            Clients = new ObservableCollection<Client>(_context.Client.AsNoTracking().ToList());

            AddCommand = new RelayCommand(AddOrder);
            DeleteCommand = new RelayCommand(DeleteOrder, CanDeleteOrder);
            SaveCommand = new RelayCommand(SaveOrders);
        }

        private void AddOrder(object parameter)
        {
            var newOrder = new Orders
            {
                OrderDate = DateTime.Now,
                Status = "Новый",
                Client = Clients.FirstOrDefault()
            };
            Orders.Add(newOrder);
            _context.Orders.Add(newOrder);
            SelectedOrder = newOrder;
        }

        private bool CanDeleteOrder(object parameter) => SelectedOrder != null;

        private void DeleteOrder(object parameter)
        {
            if (MessageBox.Show("Удалить заказ?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                try
                {
                    _context.Orders.Remove(SelectedOrder);
                    Orders.Remove(SelectedOrder);
                    _context.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка удаления: {ex.Message}");
                }
            }
        }

        private void SaveOrders(object parameter)
        {
            try
            {
                _context.SaveChanges();
                MessageBox.Show("Данные заказов сохранены!");
            }
            catch (DbUpdateException ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.InnerException?.Message}");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}