﻿using Microsoft.EntityFrameworkCore;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using WpfApp2.Models;

namespace WpfApp2.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private ObservableCollection<Box> _box;
        private ObservableCollection<Client> _client;
        private ObservableCollection<Spare_parts> _sparePart;
        private ObservableCollection<Orders> _order;

        // Изменено на public
        public ObservableCollection<Box> Boxes
        {
            get => _box;
            set { _box = value; OnPropertyChanged(nameof(Boxes)); }
        }

        // Изменено на public
        public ObservableCollection<Client> Clients
        {
            get => _client;
            set { _client = value; OnPropertyChanged(nameof(Clients)); }
        }

        // Изменено на public (обратите внимание на правильное написание SpareParts)
        public ObservableCollection<Spare_parts> SpareParts
        {
            get => _sparePart;
            set { _sparePart = value; OnPropertyChanged(nameof(SpareParts)); }
            }

        // Изменено на public
        public ObservableCollection<Orders> Orders
        {
            get => _order;
            set { _order = value; OnPropertyChanged(nameof(Orders)); }
        }

        public MainViewModel()
        {
            LoadData();
        }

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


       private void LoadData()
{
    try
    {
        using (var context = new AppDbContext())
        {
            // Альтернатива EnableSensitiveDataLogging() для старых версий
            var debugView = context.Spare_parts
                .Include(sp => sp.Box)
                .AsNoTracking()
                .ToQueryString(); // Генерирует SQL-запрос без выполнения

            Console.WriteLine("Сгенерированный SQL запрос:\n" + debugView);

            var spareParts = context.Spare_parts
                .Include(sp => sp.Box)
                .AsNoTracking()
                .ToList();

            // Диагностика
            Console.WriteLine($"Загружено запчастей: {spareParts.Count}");
            foreach (var part in spareParts.Take(5))
            {
                Console.WriteLine($"{part.Name} -> Box: {(part.Box != null ? part.Box.Model : "NULL")}");
            }

            SpareParts = new ObservableCollection<Spare_parts>(spareParts);
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show($"Ошибка загрузки: {ex.Message}\n{ex.InnerException?.Message}");
    }
}
    }
    }
